// $("#filter_branch_btn").click(function () {
//     const filterText = $("#filter_box").val().toLowerCase();

//     const filteredArray = array.filter((item) => {
//         return item.branch_kh?.toLowerCase().includes(filterText);
//     });

//     array = filteredArray;
//     current_index = 1;
// });

// $("#filter_box").on("input", function () {
//     if ($(this).val() === "") {
//         array = [...originalArray];
//         current_index = 1;
//         displayIndexButtons();
//     }
// });
